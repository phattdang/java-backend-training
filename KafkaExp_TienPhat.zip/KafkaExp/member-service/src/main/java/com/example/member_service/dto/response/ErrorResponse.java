package com.example.member_service.dto.response;

public record ErrorResponse(String message) {
}

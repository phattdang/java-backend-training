package com.example.member_service.entity.enums;

public enum MessageError {
    MEMBER_NOT_FOUND("Member not found");

    private final String message;

    MessageError(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}

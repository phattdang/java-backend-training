package com.example.member_service.service;

import com.example.member_service.entity.Member;

public interface MemberService {
    Member getById(String id);

    Member updateMember(String memberId, Member newInformation);
}

package com.example.member_service.service.impl;

import com.example.member_service.entity.Member;
import com.example.member_service.exception.custom.member.MemberNotFoundException;
import com.example.member_service.service.MemberService;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class MemberServiceImpl implements MemberService {
    List<Member> members = List.of(
            new Member("1", "John Doe", "john.doe@example.com", "123-456-7890"),
            new Member("2", "Jane Smith", "jane.smith@example.com", "098-765-4321"),
            new Member("3", "Alice Johnson", "alice.johnson@example.com", "555-555-5555")
    );

    @Cacheable(value = "members", key = "#id")
    @Override
    public Member getById(String id) {
        log.info("The first time fetching member with ID: {}", id);

        // them sleep vao de thay su khac biet khi goi lan dau va lan sau, de minh co the kiem tra cache
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        return members.stream()
                .filter(member -> member.getMemberId().equals(id))
                .findFirst()
                .orElseThrow(() -> new MemberNotFoundException(id));
    }

    @CachePut(value = "members", key = "#id")
    @Override
    public Member updateMember(String id, Member newInformation) {
        Member member = members.stream()
                .filter(m -> m.getMemberId().equals(id))
                .findFirst()
                .orElseThrow(() ->
                        new MemberNotFoundException(id)
                );

        member.setName(newInformation.getName());
        member.setEmail(newInformation.getEmail());
        member.setPhone(newInformation.getPhone());

        return member;
    }
}

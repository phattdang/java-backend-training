package com.example.member_service.exception.custom.member;

import com.example.member_service.entity.enums.MessageError;

public class MemberNotFoundException extends RuntimeException {

    public MemberNotFoundException(String memberId) {
        super(MessageError.MEMBER_NOT_FOUND.getMessage() + ": " + memberId);
    }
}

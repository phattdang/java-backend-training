package com.example.member_service.controller;

import com.example.member_service.entity.Member;
import com.example.member_service.service.MemberService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@RequestMapping("/api/members")
public class MemberController {
    MemberService memberService;

    @GetMapping("/{memberId}")
    ResponseEntity<Member> getMemberById(@PathVariable String memberId) {
        Member member = memberService.getById(memberId);
        return ResponseEntity.status(HttpStatus.OK).body(member);
    }

    @PutMapping("/{memberId}")
    ResponseEntity<Member> updateMember(@PathVariable String memberId, @RequestBody Member newInformation) {
        Member member = memberService.updateMember(memberId, newInformation);
        return ResponseEntity.status(HttpStatus.OK).body(member);
    }
}

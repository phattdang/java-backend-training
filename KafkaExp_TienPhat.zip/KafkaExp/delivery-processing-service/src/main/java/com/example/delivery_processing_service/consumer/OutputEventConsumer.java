package com.example.delivery_processing_service.consumer;

import com.example.delivery_processing_service.dto.response.OutputEvent;
import com.example.delivery_processing_service.service.event.OutputEventProcessingService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@RequiredArgsConstructor
@Slf4j
public class OutputEventConsumer {
    OutputEventProcessingService outputEventProcessingService;

    @KafkaListener(
            topics = "${app.kafka.topic.output}",
            containerFactory = "outputEventKafkaListenerContainerFactory"
    )
    public void consume(List<OutputEvent> events) {
        log.info("Received output event batch: size={}", events.size());

        events.forEach(outputEventProcessingService::processOutputEvent);
    }
}

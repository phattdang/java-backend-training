package com.example.delivery_processing_service.service.event.impl;

import com.example.delivery_processing_service.dto.response.OutputEvent;
import com.example.delivery_processing_service.entity.enums.Channel;
import com.example.delivery_processing_service.service.event.OutputEventProcessingService;
import com.example.delivery_processing_service.service.processor.Processor;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class OutputEventProcessingServiceImpl implements OutputEventProcessingService {
    Map<Channel, Processor> processors;

    public OutputEventProcessingServiceImpl(List<Processor> processors) {
        this.processors = processors.stream()
                .collect(Collectors
                        .toMap(
                                Processor::support,
                                processor -> processor)
                );
    }

    @Override
    public void processOutputEvent(OutputEvent event) {
        Processor processor = processors.get(event.channel());
        if (processor == null)
            throw new NullPointerException("Processor is null!");
        processor.process(event);
    }
}

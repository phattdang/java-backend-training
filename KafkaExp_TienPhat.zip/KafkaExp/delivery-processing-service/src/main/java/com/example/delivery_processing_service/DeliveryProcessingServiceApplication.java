package com.example.delivery_processing_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliveryProcessingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeliveryProcessingServiceApplication.class, args);
	}

}

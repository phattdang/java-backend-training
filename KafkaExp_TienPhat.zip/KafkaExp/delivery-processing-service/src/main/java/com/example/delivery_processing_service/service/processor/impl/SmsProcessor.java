package com.example.delivery_processing_service.service.processor.impl;

import com.example.delivery_processing_service.dto.response.OutputEvent;
import com.example.delivery_processing_service.entity.enums.Channel;
import com.example.delivery_processing_service.service.processor.Processor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SmsProcessor implements Processor {
    @Override
    public Channel support() {
        return Channel.SMS;
    }

    @Override
    public void process(OutputEvent event) {
        log.info("Processing SMS event!");
    }

}

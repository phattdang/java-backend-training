package com.example.delivery_processing_service.service.processor;


import com.example.delivery_processing_service.dto.response.OutputEvent;
import com.example.delivery_processing_service.entity.enums.Channel;

public interface Processor {
    Channel support();

    void process(OutputEvent event);
}

package com.example.delivery_processing_service.config.kafka.consumerfactory;

import com.example.delivery_processing_service.dto.response.OutputEvent;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.boot.kafka.autoconfigure.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.support.serializer.JacksonJsonDeserializer;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class OutputEventKafkaConsumerConfig {

    @Bean
    ConsumerFactory<String, OutputEvent> outputEventConsumerFactory(KafkaProperties kafkaProperties) {
        // lay cac cau hinh properties tu application.properties va build consumer properties
        Map<String, Object> consumerProperties = new HashMap<>(kafkaProperties.buildConsumerProperties());

        // xoa 2 cai cai deserializer class config de su dung custom deserializer
        consumerProperties.remove(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG);
        consumerProperties.remove(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG);

        // tra ve consumer factory voi cac cau hinh va deserializer da tao
        return new DefaultKafkaConsumerFactory<>(
                consumerProperties,
                new StringDeserializer(),
                new JacksonJsonDeserializer<>(OutputEvent.class, false)
        );
    }

    @Bean
    ConcurrentKafkaListenerContainerFactory<String, OutputEvent> outputEventKafkaListenerContainerFactory(
            ConsumerFactory<String, OutputEvent> outputEventConsumerFactory
    ) {
        ConcurrentKafkaListenerContainerFactory<String, OutputEvent> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(outputEventConsumerFactory);
        factory.setBatchListener(true);
        return factory;
    }
}

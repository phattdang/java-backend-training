package com.example.delivery_processing_service.service.event;

import com.example.delivery_processing_service.dto.response.OutputEvent;

public interface OutputEventProcessingService {
    void processOutputEvent(OutputEvent event);
}

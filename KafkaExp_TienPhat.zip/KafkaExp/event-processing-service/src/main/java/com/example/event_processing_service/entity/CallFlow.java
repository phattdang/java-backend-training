package com.example.event_processing_service.entity;

public class CallFlow {
    private String flowId;
    private String memberName;
    private String message;

    // Constructors
    public CallFlow() {
    }

    public CallFlow(String flowId, String memberName, String message) {
        this.flowId = flowId;
        this.memberName = memberName;
        this.message = message;
    }

    // Getters and Setters
    public String getFlowId() {
        return flowId;
    }

    public void setFlowId(String flowId) {
        this.flowId = flowId;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

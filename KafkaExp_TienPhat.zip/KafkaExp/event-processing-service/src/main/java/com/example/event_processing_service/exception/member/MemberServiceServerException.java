package com.example.event_processing_service.exception.member;

public class MemberServiceServerException extends RuntimeException {

    public MemberServiceServerException(String message) {
        super(message);
    }
}

package com.example.event_processing_service.config.kafka.producerfactory;

import com.example.event_processing_service.dto.request.InputEvent;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.kafka.autoconfigure.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.DelegatingByTypeSerializer;
import org.springframework.kafka.support.serializer.JacksonJsonSerializer;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class InputEventDLTKafkaProducerConfig {
    @Bean
    ProducerFactory<String, Object> inputEventDLTProducerFactory(KafkaProperties kafkaProperties) {
        Map<String, Object> properties = new HashMap<>(kafkaProperties.buildProducerProperties());

        properties.remove(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG);
        properties.remove(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG);

        return new DefaultKafkaProducerFactory<>(
                properties,
                new StringSerializer(),
                new DelegatingByTypeSerializer(Map.of(
                        byte[].class, new ByteArraySerializer(),
                        InputEvent.class, new JacksonJsonSerializer<Object>()
                ))
        );
    }

    @Bean
    KafkaTemplate<String, Object> inputEventDLTKafkaTemplate(ProducerFactory<String, Object> inputEventDLTProducerFactory) {
        return new KafkaTemplate<>(inputEventDLTProducerFactory);
    }
}

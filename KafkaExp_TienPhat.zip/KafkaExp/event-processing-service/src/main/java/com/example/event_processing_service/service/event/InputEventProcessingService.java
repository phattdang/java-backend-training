package com.example.event_processing_service.service.event;

import com.example.event_processing_service.dto.request.InputEvent;

public interface InputEventProcessingService {

    void processEvent(InputEvent event);
}

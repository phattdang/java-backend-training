package com.example.event_processing_service.exception.member;

public class MemberServiceConnectionException extends RuntimeException {

    public MemberServiceConnectionException(String message) {
        super(message);
    }
}

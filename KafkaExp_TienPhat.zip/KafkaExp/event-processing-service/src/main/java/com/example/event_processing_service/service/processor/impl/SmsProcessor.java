package com.example.event_processing_service.service.processor.impl;

import com.example.event_processing_service.dto.response.MemberResponse;
import com.example.event_processing_service.dto.response.OutputEvent;
import com.example.event_processing_service.entity.enums.Channel;
import com.example.event_processing_service.service.processor.Processor;
import org.springframework.stereotype.Service;

@Service
public class SmsProcessor implements Processor {
    @Override
    public Channel support() {
        return Channel.SMS;
    }

    @Override
    public OutputEvent process(MemberResponse memberResponse) {
        return new OutputEvent(
                memberResponse.memberId(),
                Channel.SMS,
                null,
                "This is a sample SMS message.",
                null
        );
    }
}

package com.example.event_processing_service.dto.response;

import com.example.event_processing_service.entity.CallFlow;
import com.example.event_processing_service.entity.enums.Channel;

public record OutputEvent(
        String memberId,
        Channel channel,
        String html,
        String smsMessage,
        CallFlow callFlow
) {
}

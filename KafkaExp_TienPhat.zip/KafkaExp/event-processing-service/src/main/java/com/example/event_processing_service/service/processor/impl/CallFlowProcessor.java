package com.example.event_processing_service.service.processor.impl;

import com.example.event_processing_service.dto.response.MemberResponse;
import com.example.event_processing_service.dto.response.OutputEvent;
import com.example.event_processing_service.entity.CallFlow;
import com.example.event_processing_service.entity.enums.Channel;
import com.example.event_processing_service.service.processor.Processor;
import org.springframework.stereotype.Service;

@Service
public class CallFlowProcessor implements Processor {
    @Override
    public Channel support() {
        return Channel.CALL_FLOW;
    }

    @Override
    public OutputEvent process(MemberResponse memberResponse) {
        CallFlow callFlow = new CallFlow(
                "1",
                "Sample Call Flow",
                "This is a sample call flow description."
        );
        return new OutputEvent(
                memberResponse.memberId(),
                Channel.CALL_FLOW,
                null,
                null,
                callFlow
        );
    }
}

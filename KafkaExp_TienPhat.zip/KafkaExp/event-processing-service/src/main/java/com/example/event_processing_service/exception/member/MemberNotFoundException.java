package com.example.event_processing_service.exception.member;


import com.example.event_processing_service.entity.enums.MessageError;

public class MemberNotFoundException extends RuntimeException {

    public MemberNotFoundException(String memberId) {
        super(MessageError.MEMBER_NOT_FOUND.getMessage() + ": " + memberId);
    }
}

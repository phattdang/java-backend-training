package com.example.event_processing_service.service.processor;

import com.example.event_processing_service.dto.response.MemberResponse;
import com.example.event_processing_service.dto.response.OutputEvent;
import com.example.event_processing_service.entity.enums.Channel;

public interface Processor {
    Channel support();
    
    OutputEvent process(MemberResponse memberResponse);
}

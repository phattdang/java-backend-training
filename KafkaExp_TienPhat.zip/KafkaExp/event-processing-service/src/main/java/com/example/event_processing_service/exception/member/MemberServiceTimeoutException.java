package com.example.event_processing_service.exception.member;

public class MemberServiceTimeoutException extends RuntimeException {

    public MemberServiceTimeoutException(String message) {
        super(message);
    }
}
package com.example.event_processing_service.config.kafka.errorhandler;

import com.example.event_processing_service.exception.member.MemberNotFoundException;
import com.example.event_processing_service.exception.member.MemberServiceClientException;
import org.apache.kafka.common.TopicPartition;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.backoff.FixedBackOff;

@Configuration
public class KafkaErrorHandlerConfig {

    @Bean
    public DefaultErrorHandler kafkaErrorHandler(
            DeadLetterPublishingRecoverer deadLetterPublishingRecoverer
    ) {

        // chờ 10 giây giữa mỗi lần retry
        // retry tối đa 3 lần
        FixedBackOff backOff = new FixedBackOff(10000L, 3L);

        DefaultErrorHandler errorHandler = new DefaultErrorHandler(deadLetterPublishingRecoverer, backOff);

        // không retry khi gặp MemberNotFoundException
        errorHandler.addNotRetryableExceptions(MemberNotFoundException.class);
        errorHandler.addNotRetryableExceptions(MemberServiceClientException.class);

        return errorHandler;
    }

    @Bean
    DeadLetterPublishingRecoverer deadLetterPublishingRecoverer(
            @Qualifier("inputEventDLTKafkaTemplate") KafkaTemplate<String, Object> inputEventDLTKafkaTemplate
    ) {
        return new DeadLetterPublishingRecoverer(
                inputEventDLTKafkaTemplate,
                (record, exception) ->
                        new TopicPartition(
                                record.topic() + ".DLT", // ten cua DLT
                                record.partition()
                        )
        );
    }
}

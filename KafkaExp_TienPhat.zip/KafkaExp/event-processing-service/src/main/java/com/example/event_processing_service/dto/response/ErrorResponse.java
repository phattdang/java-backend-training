package com.example.event_processing_service.dto.response;

public record ErrorResponse(String message) {
}

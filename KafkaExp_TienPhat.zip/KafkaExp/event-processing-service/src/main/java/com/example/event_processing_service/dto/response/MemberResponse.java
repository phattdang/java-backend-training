package com.example.event_processing_service.dto.response;

public record MemberResponse (
         String memberId,
         String name,
         String email,
         String phone
) {
}

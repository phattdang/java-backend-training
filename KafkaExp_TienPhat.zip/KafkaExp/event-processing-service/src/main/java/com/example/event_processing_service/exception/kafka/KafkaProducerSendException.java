package com.example.event_processing_service.exception.kafka;

public class KafkaProducerSendException extends RuntimeException {

    public KafkaProducerSendException(String message, Throwable cause) {
        super(message, cause);
    }
}
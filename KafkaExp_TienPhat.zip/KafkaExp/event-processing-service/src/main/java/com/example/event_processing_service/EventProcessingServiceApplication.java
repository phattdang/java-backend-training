package com.example.event_processing_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventProcessingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventProcessingServiceApplication.class, args);
	}

}

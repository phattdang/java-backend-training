package com.example.event_processing_service.config.kafka.producerfactory;

import com.example.event_processing_service.dto.response.OutputEvent;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.kafka.autoconfigure.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JacksonJsonSerializer;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class OutputEventKafkaProducerConfig {

    @Bean
    ProducerFactory<String, OutputEvent> outputEventProducerFactory(KafkaProperties kafkaProperties) {
        Map<String, Object> producerProperties = new HashMap<>(kafkaProperties.buildProducerProperties());

        producerProperties.remove(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG);
        producerProperties.remove(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG);

        JacksonJsonSerializer<OutputEvent> valueSerializer = new JacksonJsonSerializer<OutputEvent>().noTypeInfo();

        return new DefaultKafkaProducerFactory<>(
                producerProperties,
                new StringSerializer(),
                valueSerializer
        );
    }

    @Bean
    KafkaTemplate<String, OutputEvent> outputEventKafkaTemplate(
            ProducerFactory<String, OutputEvent> outputEventProducerFactory
    ) {
        return new KafkaTemplate<>(outputEventProducerFactory);
    }
}

package com.example.event_processing_service.client;

import com.example.event_processing_service.dto.response.MemberResponse;
import com.example.event_processing_service.exception.member.*;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.concurrent.TimeoutException;

@Component
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class MemberClient {
    private static final String MEMBER_API_BASE_URL = "/api/members/{id}";
    WebClient memberWebClient;

    public MemberClient(WebClient memberWebClient) {
        this.memberWebClient = memberWebClient;
    }

    public MemberResponse getMember(String memberId) {
        return memberWebClient
                .get()
                .uri(MEMBER_API_BASE_URL, memberId)
                .retrieve()

                .onStatus(
                        status -> status.value() == 404,
                        response -> Mono.error(new MemberNotFoundException(memberId))
                )
                .onStatus(
                        HttpStatusCode::is4xxClientError,
                        response -> Mono.error(
                                new MemberServiceClientException("Member service client error: " + response.statusCode())
                        )
                )
                .onStatus(
                        HttpStatusCode::is5xxServerError,
                        response -> Mono.error(
                                new MemberServiceServerException("Member service server error: " + response.statusCode())
                        )
                )
                .bodyToMono(MemberResponse.class)
                .timeout(Duration.ofSeconds(5))
                .onErrorMap(
                        TimeoutException.class,
                        exception -> new MemberServiceTimeoutException("Member service request timed out")
                )
                .onErrorMap(
                        WebClientRequestException.class,
                        exception -> new MemberServiceConnectionException("Cannot connect to member service")
                )
                .block();
    }
}

package com.example.event_processing_service.producer;

import com.example.event_processing_service.dto.response.OutputEvent;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

@Component
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class OutputEventProducer {

    KafkaTemplate<String, OutputEvent> kafkaTemplate;
    String outputTopic;

    public OutputEventProducer(
            @Qualifier("outputEventKafkaTemplate") KafkaTemplate<String, OutputEvent> kafkaTemplate,
            @Value("${app.kafka.topic.output}") String outputTopic
    ) {
        this.kafkaTemplate = kafkaTemplate;
        this.outputTopic = outputTopic;
    }

    public CompletableFuture<SendResult<String, OutputEvent>> send(OutputEvent event) {
        return kafkaTemplate.send(outputTopic, event.memberId(), event);
    }

//    public CompletableFuture<SendResult<String, OutputEvent>> send(OutputEvent event) {
//        return CompletableFuture.failedFuture(
//                new RuntimeException("Test producer failure")
//        );
//    }
}

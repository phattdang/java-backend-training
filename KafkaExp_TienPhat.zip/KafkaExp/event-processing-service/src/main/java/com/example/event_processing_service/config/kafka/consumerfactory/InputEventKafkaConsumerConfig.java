package com.example.event_processing_service.config.kafka.consumerfactory;

import com.example.event_processing_service.dto.request.InputEvent;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.boot.kafka.autoconfigure.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.kafka.support.serializer.JacksonJsonDeserializer;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class InputEventKafkaConsumerConfig {

    @Bean
    ConsumerFactory<String, InputEvent> inputEventConsumerFactory(KafkaProperties kafkaProperties) {
        // lay cac cau hinh properties tu application.properties va build consumer properties
        Map<String, Object> consumerProperties = new HashMap<>(kafkaProperties.buildConsumerProperties());

        // xoa 2 cai cai deserializer class config de su dung custom deserializer
        consumerProperties.remove(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG);
        consumerProperties.remove(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG);

//        // tao deserializer cho key va value
//        StringDeserializer keyDeserializer = new StringDeserializer();
//        JacksonJsonDeserializer<InputEvent> valueDeserializer = new JacksonJsonDeserializer<>(InputEvent.class, false);
//
//        // tra ve consumer factory voi cac cau hinh va deserializer da tao
//        return new DefaultKafkaConsumerFactory<>(
//                consumerProperties,
//                keyDeserializer,
//                valueDeserializer
//        );

        // tra ve consumer factory voi cac cau hinh va deserializer da tao
        return new DefaultKafkaConsumerFactory<>(
                consumerProperties,
                new StringDeserializer(),
                new ErrorHandlingDeserializer<>(new JacksonJsonDeserializer<>(InputEvent.class, false))
        );
    }

    @Bean
    ConcurrentKafkaListenerContainerFactory<String, InputEvent> inputEventKafkaListenerContainerFactory(
            ConsumerFactory<String, InputEvent> inputEventConsumerFactory,
            DefaultErrorHandler defaultErrorHandler
    ) {
        ConcurrentKafkaListenerContainerFactory<String, InputEvent> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(inputEventConsumerFactory);
        factory.setCommonErrorHandler(defaultErrorHandler);
        return factory;
    }
}

package com.example.event_processing_service.entity.enums;

public enum Channel {
    EMAIL,
    SMS,
    CALL_FLOW
}

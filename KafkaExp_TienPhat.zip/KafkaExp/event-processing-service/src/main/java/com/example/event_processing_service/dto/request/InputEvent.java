package com.example.event_processing_service.dto.request;

import com.example.event_processing_service.entity.enums.Channel;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record InputEvent(
    @NotBlank(message = "memberId must not be blank")
    String memberId,

    @NotNull(message = "channel must not be null")
    Channel channel
) {
}

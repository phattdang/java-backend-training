package com.example.event_processing_service.exception.member;

public class MemberServiceClientException extends RuntimeException {

    public MemberServiceClientException(String message) {
        super(message);
    }
}
package com.example.event_processing_service.consumer;

import com.example.event_processing_service.dto.request.InputEvent;
import com.example.event_processing_service.service.event.InputEventProcessingService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@RequiredArgsConstructor
@Slf4j
public class InputEventConsumer {
    InputEventProcessingService inputEventProcessingService;

    @KafkaListener(
            topics = "${app.kafka.topic.input}",
            containerFactory = "inputEventKafkaListenerContainerFactory"
    )
    public void consume(InputEvent event) {
        inputEventProcessingService.processEvent(event);
    }
}

package com.example.event_processing_service.service.event.impl;

import com.example.event_processing_service.client.MemberClient;
import com.example.event_processing_service.dto.request.InputEvent;
import com.example.event_processing_service.dto.response.MemberResponse;
import com.example.event_processing_service.dto.response.OutputEvent;
import com.example.event_processing_service.entity.enums.Channel;
import com.example.event_processing_service.exception.kafka.KafkaProducerSendException;
import com.example.event_processing_service.producer.OutputEventProducer;
import com.example.event_processing_service.service.event.InputEventProcessingService;
import com.example.event_processing_service.service.processor.Processor;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletionException;
import java.util.stream.Collectors;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class InputEventProcessingServiceImpl implements InputEventProcessingService {
    MemberClient memberClient;
    Map<Channel, Processor> processors;
    OutputEventProducer outputEventProducer;

    public InputEventProcessingServiceImpl(MemberClient memberClient, OutputEventProducer outputEventProducer, List<Processor> processors) {
        this.memberClient = memberClient;
        this.outputEventProducer = outputEventProducer;
        this.processors = processors.stream().collect(Collectors.toMap(Processor::support, processor -> processor));
    }

    @Override
    public void processEvent(InputEvent event) {
        MemberResponse memberResponse = memberClient.getMember(event.memberId());

        Processor processor = processors.get(event.channel());
        if (processor == null) throw new IllegalArgumentException("No processor found for channel: " + event.channel());
        OutputEvent outputEvent = processor.process(memberResponse);
        try {
//            try {
//                log.info("Delay 15s");
//                Thread.sleep(15_000);
//            } catch (InterruptedException e) {
//                Thread.currentThread().interrupt();
//            }

            SendResult<String, OutputEvent> result = outputEventProducer.send(outputEvent).join();

            log.info(
                    "Sent output event successfully: topic={}, partition={}, offset={}",
                    result.getRecordMetadata().topic(),
                    result.getRecordMetadata().partition(),
                    result.getRecordMetadata().offset()
            );

            log.info("Submitted output event to Kafka: {}", outputEvent);

            // check xem sau khi update cache co lay duoc member moi nhat hay khong
            log.info("member: {}", memberResponse);

        } catch (CompletionException e) {
            throw new KafkaProducerSendException("Failed to send output event", e.getCause());
        }
    }
}
package com.example.event_processing_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InputEventProcessingServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
